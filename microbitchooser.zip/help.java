import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

// Autor: Vinzent Schowald
// Datum: 24.07.2022

public class help extends JFrame {
  // Anfang Attribute
  private JButton bSchliesen = new JButton();
  private JButton jButton1 = new JButton();
  private ImageIcon jButton1Icon = new ImageIcon(getClass().getResource("images/landtag-wettbewerb-eule -- Quelle Landtag NRW Vera Bruggemann_skal.jpg"));
  private JList jList1 = new JList();
    private DefaultListModel jList1Model = new DefaultListModel();
    private JScrollPane jList1ScrollPane = new JScrollPane(jList1);
  // Ende Attribute
  
  public help() { 
    // Frame-Initialisierung
    super();
    setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
    int frameWidth = 569; 
    int frameHeight = 159;
    setSize(frameWidth, frameHeight);
    Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
    int x = (d.width - getSize().width) / 2;
    int y = (d.height - getSize().height) / 2;
    setLocation(x, y);
    setTitle("Hilfe");
    setResizable(false);
    Container cp = getContentPane();
    cp.setLayout(null);
    // Anfang Komponenten
    jList1.setModel(jList1Model);
    jList1ScrollPane.setBounds(112, 8, 430, 76);
    jList1ScrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
    jList1ScrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
    jList1.setSelectionBackground(Color.WHITE);
    jList1.setSelectionForeground(Color.WHITE);
    jList1.setForeground(Color.BLACK);
    cp.add(jList1ScrollPane);
    jButton1.setBounds(8, 8, 99, 105);
    jButton1.setText("");
    jButton1.setMargin(new Insets(2, 2, 2, 2));
    jButton1.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        jButton1_ActionPerformed(evt);
      }
    });
    jButton1.setIcon(jButton1Icon);
    jButton1.setHorizontalTextPosition(SwingConstants.CENTER);
    jButton1.setBorderPainted(false);
    jButton1.setContentAreaFilled(false);
    jButton1.setFocusPainted(false);
    cp.add(jButton1);
    bSchliesen.setBounds(112, 88, 430, 25);
    bSchliesen.setText("Schliesen");
    bSchliesen.setMargin(new Insets(2, 2, 2, 2));
    bSchliesen.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        bSchliesen_ActionPerformed(evt);
      }
    });
    bSchliesen.setBackground(new Color(0x006FA8));
    bSchliesen.setForeground(Color.WHITE);
    cp.add(bSchliesen);
    
    cp.setBackground(Color.WHITE);
    setUndecorated(false);
    // Ende Komponenten
    jList1Model.addElement("Das heruntergeladene Programm befindet sich im normalfall im Ordner");
    jList1Model.addElement("\"Downloads\". Der Microbit sollte automatisch ausgewaehlt sein, falls");
    jList1Model.addElement("nicht kannst du ihn einfach auswaehlen. Im Fall das er nicht angezeigt");
    jList1Model.addElement("wird kannst du ihn bei Erweitert unter \"Dieser PC\" finden");
    setVisible(true);
  } // end of public help
  
  // Anfang Methoden
  
  public static void main(String[] args) {
    //new help();
  } // end of main
  
  public void bSchliesen_ActionPerformed(ActionEvent evt) {
    setVisible(false);
    // TODO hier Quelltext einfgen
    
  } // end of bSchliesen_ActionPerformed

  public void jButton1_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einfgen
    
  } // end of jButton1_ActionPerformed

  // Ende Methoden
} // end of class help
