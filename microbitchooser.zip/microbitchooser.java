import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.io.*;
import static java.nio.file.StandardCopyOption.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import javax.swing.JRadioButton;
import javax.swing.filechooser.FileSystemView;
import javax.swing.JButton;

// Autor: Vinzent Schowald
// Datum: 26.07.2022

public class microbitchooser extends JFrame {
  // Anfang Attribute
  private JRadioButton[] jRadioButtonDrives ;
  private ButtonGroup buttonGroup1 = new ButtonGroup();
  private Gui dieGui;
  private JButton bAuswaehlen = new JButton();
  private JButton bErweitert = new JButton();
  private JButton bCancel = new JButton();
  private JLabel lBittedenMicroBitauswaehlen = new JLabel();
  // Ende Attribute
  
  public microbitchooser(Gui dieGui) { 
    // Frame-Initialisierung
    super();
    this.dieGui=dieGui;
    setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
    int frameWidth = 250; 
    int frameHeight = 80+(22*(File.listRoots().length+2));
    setSize(frameWidth, frameHeight);
    Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
    int x = (d.width - getSize().width) / 2;
    int y = (d.height - getSize().height) / 2;
    setLocation(x, y);
    setTitle("Microbit Auswaehlen");
    setResizable(false);
    Container cp = getContentPane();
    cp.setLayout(null);
    // Anfang Komponenten
    lBittedenMicroBitauswaehlen.setBounds(20, 0, 176, 20);
    lBittedenMicroBitauswaehlen.setText("Bitte den MicroBit auswaehlen");
    cp.add(lBittedenMicroBitauswaehlen);
    
    for (int icount=0;icount<File.listRoots().length;icount++ ) {
      //System.out.println(File.listRoots()[icount]);
      //File f = File.listRoots()[icount];
      //System.out.println(FileSystemView.getFileSystemView().getSystemDisplayName(f));
    } // end of for
    
    cp.setBackground(Color.WHITE);
    // Ende Komponenten
    JRadioButton[] buttons = new JRadioButton[10];
    int hight = 22;
    for (int i=0;i< File.listRoots().length;i++ ) {
      File f = File.listRoots()[i];
      buttons[i] = new JRadioButton(String.valueOf(FileSystemView.getFileSystemView().getSystemDisplayName(f)));
      int lenght = FileSystemView.getFileSystemView().getSystemDisplayName(f).length() *10;
      buttons[i].setBounds(20,hight,lenght,20);
      buttons[i].setBackground(new Color(0x006FA8));
      buttons[i].setForeground(Color.WHITE);
      buttonGroup1.add(buttons[i]);
      cp.add(buttons[i]);
      hight+=22;
      if (buttons[i].getText()=="MICROBIT") 
      {
        buttons[i].setSelected(true);
      } else if (buttons[i].getText()!="OS") 
        {
          buttons[i].setSelected(true); 
        } // end of if
    } // end of for
    hight+=5;
    bAuswaehlen.setBounds(20, hight, 202, 25);
    bAuswaehlen.setText("Auswaehlen");
    bAuswaehlen.setMargin(new Insets(2, 2, 2, 2));
    bAuswaehlen.setBackground(new Color(0x006FA8));
    bAuswaehlen.setForeground(Color.WHITE);
    bAuswaehlen.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        bAuswaehlen_ActionPerformed(evt);
      }
    });
    bAuswaehlen.setText("Auswaehlen");
    bAuswaehlen.setFont(new Font("Dialog", Font.BOLD, 20));
    cp.add(bAuswaehlen);
    hight += 27;
    bErweitert.setBounds(20, hight, 100, 25);
    bErweitert.setText("Erweitert");
    bErweitert.setMargin(new Insets(2, 2, 2, 2));
    bErweitert.setBackground(new Color(0x006FA8));
    bErweitert.setForeground(Color.WHITE);
    bErweitert.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        bErweitert_ActionPerformed(evt);
      }
    });
    bErweitert.setText("Erweitert");
    cp.add(bErweitert);
    bCancel.setBounds(122, hight, 100, 25);
    bCancel.setText("Abbrechen");
    bCancel.setMargin(new Insets(2, 2, 2, 2));
    bCancel.setBackground(new Color(0x006FA8));
    bCancel.setForeground(Color.WHITE);
    bCancel.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        bCancel_ActionPerformed(evt);
      }
    });
    bCancel.setText("Abbrechen");
    cp.add(bCancel);
    hight+=27;
    hight+=27;
    setVisible(true);
  } // end of public microbitchooser
  // Anfang Methoden
  public static void main(String[] args) {
    
  } // end of main
  
  public String buttonGroup1_getSelectedRadioButtonLabel() {
    for (java.util.Enumeration<AbstractButton> e = buttonGroup1.getElements(); e.hasMoreElements();) {
      AbstractButton b = e.nextElement();
      if (b.isSelected()) return b.getText();
    }
    return "";
  }
  
  public void bAuswaehlen_ActionPerformed(ActionEvent evt) {
    String temp ="";
    //System.out.println(buttonGroup1_getSelectedRadioButtonLabel());
    temp = buttonGroup1_getSelectedRadioButtonLabel().substring(buttonGroup1_getSelectedRadioButtonLabel().indexOf(':')-1,buttonGroup1_getSelectedRadioButtonLabel().indexOf(':')+1);
    temp = temp + "\\";
    //System.out.println(temp);
    dieGui.setTargetpath(temp);
    dieGui.setFile2sel(true);
    dieGui.setSelFile(true);
    this.setVisible(false);
    
    
  } // end of bAuswaehlen_ActionPerformed
  public void bErweitert_ActionPerformed(ActionEvent evt) 
  {
    dieGui.jFileChooser2_openFile();
    //System.out.println(dieGui.filepath());
    dieGui.setTargetpath(dieGui.filepath());
    if (dieGui.filepath()!="null") {
      dieGui.setFile2sel(true);
      dieGui.setSelFile(true);
      this.setVisible(false);
    } // end of if
    
  }
  
  public void bCancel_ActionPerformed(ActionEvent evt) {
    if (dieGui.getTargetpath()=="null") {
      dieGui.cancel(false);
      dieGui.setEnabled2(false);
    } // end of if
    this.setVisible(false);
  }
  // Ende Methoden
} // end of class microbitchooser
