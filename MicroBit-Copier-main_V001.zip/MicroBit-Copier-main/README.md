# MicroBit-Copier
a simple file copier for working with the mikrobit and younger childreen.
It is a simple programm with 5 buttons and the ability to copy one file from a place to an other place. The text in the application is in german.

explanation of the buttons:
- the button with "Programm auswaehlen" on it opens an file selector where you can select the source file.
- the button with "MicroBit auswaehlen" on it opens an file selector where you can select the destination, with the intended use the microBit
- the button with "Start" is only enabled if the source and the destination are selected and it starts the copiing process
- the button with "Fertig" on it closes the programm
- the button with "Hilfe" on it opens a help menu for the intended use, wich is in german

the .jar file is the executable java file, it only works with java 18. 
the other 2 files are the source files. 
©Vinzent Schowald

